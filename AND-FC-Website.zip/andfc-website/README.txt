AND FC WEBSITE - START HERE

1. Open index.html in any browser to preview your website.
2. To publish it online, upload index.html to a static website host (such as Netlify Drop), or ask a trusted helper to do this.
3. Before publishing, add your approved official club badge, real club photographs, verified training details, official social links, safeguarding contacts, and privacy information as appropriate.
4. The contact form prepares an email in the visitor's email application. It does NOT store or send messages from a server.
5. No website hosting, domain name, or online publishing has been completed.
